int ibm_partition(struct gendisk *, struct block_device *, unsigned long, int);
